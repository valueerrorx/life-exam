pyuic5 MyCustomWidget.ui > MyCustomWidget.py
